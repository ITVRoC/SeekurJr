

USING THE JAVA WRAPPER FOR ARNL

A "wrapper" library for Java has been provided in the "java" directory.
This wrapper layer provides a Java API which simply makes calls into the 
regular Arnl C++ implementation.

To use the Arnl Java wrapper you need to download a Java SDK. Sun J2SE JDK
1.6 (Java SE6) was used to build the wrapper.  You can download it from:

    http://java.sun.com/javase/downloads

Fitnd the Java SE Development Kit 6 and click "Download".

You should install it on your system.  Then you should put the bin
directory of the SDK into your path.  

In Windows you must then put Arnl's bin directories into your PATH 
enviornment variable so that Java can find the wrapper DLLs.
Environment variables can be set in the System control panel.  

On Linux, you must add /usr/local/Arnl/lib and /usr/local/Aria/lib to your 
LD_LIBRARY_PATH environment variable, so Java can find the wrapper libraries.


FOR ARNL:

For an example you can start the simulator, then enter
the javaExamples directory and compile one of the
ARNL examples.

On Linux, compile the example like this:

    javac -classpath ../java/Arnl.jar:BaseArnl.jar:../java/Aria.jar:../java/ArNetworking.jar ArnlServer.java

On Windows, compile the example like this (using ; as the separator instead of :):

    javac -classpath ../java/Arnl.jar;../java/BaseArnl.jar;../java/Aria.jar;../java/ArNetworking.jar ArnlServer.java

Then on Linux, run it like this:

    java -cp ../java/Arnl.jar:../java/BaseArnl.jar:../java/Aria.jar:../java/ArNetworking.jar:. ArnlServer

On Windows, run it like this:

    java -cp ../java/Arnl.jar;../java/BaseArnl.jar;../java/Aria.jar;../java/ArNetworking.jar;. ArnlServer


FOR SONARNL:


On Linux, compile the example like this:

    javac -classpath ../java/SonArnl.jar:../java/BaseArnl.jar:../java/Aria.jar:../java/ArNetworking.jar SonArnlServer.java

On Windows, compile the example like this (using ; as the separator instead of :):

    javac -classpath ../java/SonArnl.jar;../java/BaseArnl.jar;../java/Aria.jar;../java/ArNetworking.jar SonArnlServer.java

Then on Linux, run it like this:

    java -cp ../java/SonArnl.jar:../java/BaseArnl.jar:../java/Aria.jar:../java/ArNetworking.jar:. SonArnlServer

On Windows, run it like this:

    java -cp ../java/SonArnl.jar;../java/BaseArnl.jar;../java/Aria.jar;../java/ArNetworking.jar;. SonArnlServer


FOR MOGS:


On Linux, compile the example like this:

    javac -classpath ../java/Mogs.jar:../java/BaseArnl.jar:../java/Aria.jar:../java/ArNetworking.jar MogsServer.java

On Windows, compile the example like this (using ; as the separator instead of :):

    javac -classpath ../java/Mogs.jar;../java/BaseArnl.jar;../java/Aria.jar;../java/ArNetworking.jar MogsServer.java

Then on Linux, run it like this:

    java -cp ../java/Mogs.jar:../java/BaseArnl.jar:../java/Aria.jar:../java/ArNetworking.jar:.  MogsServer

On Windows, run it like this:

    java -cp ../java/Mogs.jar;../java/BaseArnl.jar;../java/Aria.jar;../java/ArNetworking.jar;. MogsServer 


The Java wrapper is not as well tested as the C++ library itself. 
If you encounter problems using it, please notify the aria-users mailing list.


EXAMPLES
--------

ARNL includes the ArnlServer example program in the javaExamples directory.
SONARNL includes the SonArnlServer example program in the javaExamples directory.

There are no Java examples distributed with ArnlBase or MOGS at this time.


REBUILDING THE JAVA WRAPPER
----------------------------

If you want to rebuild the Java wrapper you need to install SWIG:
See <http://www.swig.org/download.html>  You should get at
least version 1.3.29.  You then need to set the environment variable
JAVA_INCLUDE to the include directory in your Java SDK, and
JAVA_BIN to the bin directory in your Java SDK. 

In Linux, set your path so that swig is in the path (not needed if installed
in the system default directories) then run:

make java-base    For ArnlBase
make java-arnl    For Arnl
make java-sonarnl For SonArnl
make java-mogs    For MOGS
make java-all     To build all of the above

In Windows with Visual Studio .NET, open java/ArnlJava.sln, select 
Tools menu -> Options -> Projects -> VC++ Directories and add your SWIG 
directory.  Then you should just be able to build the library.


JAVADOC

Having generated the Java wrapper library with Swig, the Java source
code will be placed in the java subdirectory.  You can use the javadoc
tool to generate an HTML outline of the API. For documentation, compare
to the C++ library API reference manual.



