"""
Adept MobileRobots Advanced Robotics Navigation and Localization (ARNL)
Version 1.9.4

Copyright (C) 2004-2005 ActivMedia Robotics LLC
Copyright (C) 2006-2009 MobileRobots Inc.
Copyright (C) 2010-2015 Adept Technology, Inc.
Copyright (C) 2016-2018 Omron Adept Technologies, Inc.

All Rights Reserved.

Adept MobileRobots does not make any representations about the
suitability of this software for any purpose.  It is provided "as is"
without express or implied warranty.

The license for this software is distributed as LICENSE.txt in the top
level directory.

robots@mobilerobots.com
Adept MobileRobots
10 Columbia Drive
Amherst, NH 03031
+1-603-881-7960

"""
from AriaPy import *
import sys

class PrintingTask:

  # Constructor. Adds a sensor interpretation task to the given robot object.
  def __init__(self, robot):
    self.myRobot = robot
    robot.addSensorInterpTask("PrintingTask", 50, self.doTask)
  
  # This method will be called by ArRobot as a sensor interpretation task
  def doTask(self):
    print "Python ArRobot sensor task function called OK.  x %6.1f  y %6.1f  th  %6.1f vel %7.1f mpacs %3d"  % (self.myRobot.getX(), self.myRobot.getY(), self.myRobot.getTh(), self.myRobot.getVel(), self.myRobot.getMotorPacCount())


def packetHandler(p):
  print 'Python packetHandler function called OK. Got packet with ID %d' % (p.getID())
  return False # Let other packet handlers have it

def connectCB():
  print 'Python robot connect callback called OK'

def disconnectCB():
  print 'Python disconnect callback called OK'

def failedConnectCB():
  print 'Python connection-failed callback called!'

def disconnectErrorCB():
  print 'Python error disconnect callback called OK'

def robotExitCB():
  print 'Python robot loop exit callback called OK'

def ariaExitCB():
  print 'Python ARIA program exit callback called OK'


Aria_init()

parser = ArArgumentParser(sys.argv)
robot = ArRobot()
con = ArRobotConnector(parser, robot)

# This object encapsulates a task we want to do every cycle. 
# Upon creation, it puts a callback functor in the ArRobot object
# as a 'sensor interpretation' task.
pt = PrintingTask(robot)

# More callbacks to make sure work in Python
robot.addConnectCB(connectCB)
robot.addFailedConnectCB(failedConnectCB)
robot.addPacketHandler(packetHandler, ArListPos.FIRST)
robot.addDisconnectNormallyCB(disconnectCB)
robot.addDisconnectOnErrorCB(disconnectErrorCB)
robot.addRunExitCB(robotExitCB)
Aria.addExitCallback(ariaExitCB)

if not con.connectRobot():
  print "Could not connect to robot, exiting"
  Aria_logOptions()
  Aria_exit(1)



print "Connected to the robot. (Press Ctrl-C to exit)"



# Start the robot process cycle running. Each cycle, it calls the robot's
# tasks. When the PrintingTask was created above, it added a new
# task to the robot. '1' means that if the robot connection
# is lost, then ArRobot's processing cycle ends and self call returns.
robot.run(1)

print "Disconnected. Goodbye."

Aria.exit(0)
