var hierarchy =
[
    [ "ArBaseLocalizationTask", "../BaseArnl-Reference/classArBaseLocalizationTask.html", [
      [ "ArLocalizationTask", "classArLocalizationTask.html", null ]
    ] ],
    [ "ArDockInterface", "classArDockInterface.html", [
      [ "ArServerModeDock", "classArServerModeDock.html", [
        [ "ArServerModeDockPioneer", "classArServerModeDockPioneer.html", null ],
        [ "ArServerModeDockTriangleBump", "classArServerModeDockTriangleBump.html", [
          [ "ArServerModeDockPatrolBot", "classArServerModeDockPatrolBot.html", [
            [ "ArServerModeDockPatrolBotNiMH", "classArServerModeDockPatrolBotNiMH.html", null ]
          ] ],
          [ "ArServerModeDockPowerBot", "classArServerModeDockPowerBot.html", null ],
          [ "ArServerModeDockSimulator", "classArServerModeDockSimulator.html", null ]
        ] ],
        [ "ArServerModeDockTriangleBumpBackwards", "classArServerModeDockTriangleBumpBackwards.html", [
          [ "ArServerModeDockLynx", "classArServerModeDockLynx.html", null ]
        ] ]
      ] ]
    ] ]
];