var classArServerModeDockPowerBot =
[
    [ "ArServerModeDockPowerBot", "classArServerModeDockPowerBot.html#a25c57b6bb4aa39750c56a0f01f3208f3", null ],
    [ "~ArServerModeDockPowerBot", "classArServerModeDockPowerBot.html#af364715b6370d9bb59b16176d80d9357", null ],
    [ "addToConfig", "classArServerModeDockPowerBot.html#af943331d2dbf38dad85ddf84321a9370", null ],
    [ "backoutCallback", "classArServerModeDockPowerBot.html#aedd17424cdc8de44d91a475110fe630f", null ],
    [ "disableDock", "classArServerModeDockPowerBot.html#aea624abc460c2710723e1b5b16bf06c2", null ],
    [ "enableDock", "classArServerModeDockPowerBot.html#aa8af229fdfd9d96622c740e555187f28", null ],
    [ "isDocked", "classArServerModeDockPowerBot.html#a8d02f37a7ee9253dd831def181811e44", null ],
    [ "myBatteryChargingGood", "classArServerModeDockPowerBot.html#a5fe3248bfa0b1b3f66866de78a13534a", null ],
    [ "myIsOldDock", "classArServerModeDockPowerBot.html#a0dad0a4064d7edae1ce795b3e6d86b70", null ],
    [ "myOldDockAnalogPort", "classArServerModeDockPowerBot.html#afdaf666943ac73001617315b120471d8", null ]
];