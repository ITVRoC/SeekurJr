var hierarchy =
[
    [ "ArBaseLocalizationTask", "../BaseArnl-Reference/classArBaseLocalizationTask.html", [
      [ "ArGPSLocalizationTask", "classArGPSLocalizationTask.html", null ]
    ] ]
];