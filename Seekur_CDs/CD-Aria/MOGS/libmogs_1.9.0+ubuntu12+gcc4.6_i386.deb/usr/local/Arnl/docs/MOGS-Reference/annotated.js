var annotated =
[
    [ "ArGPSLocalizationTask", "classArGPSLocalizationTask.html", "classArGPSLocalizationTask" ]
];