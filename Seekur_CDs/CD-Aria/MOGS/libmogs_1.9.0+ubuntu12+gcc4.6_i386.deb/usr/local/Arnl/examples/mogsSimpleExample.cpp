/*

Copyright (c) 2014 Adept Technology Inc.
All rights reserved.� 

Redistribution of this example source code, with or without modification, is 
permitted provided that the following conditions are met:�� 
-��� Redistributions must retain the above copyright notice, 
     this list of conditions and the following disclaimer.� 
-� � Redistributions must be in source code form only

The information in this document is subject to change without notice and should
not be construed as a commitment by Adept Technology, Inc.

Adept Technology, Inc. makes no warranty as to the suitability of this material
for use by the recipient, and assumes no responsibility for any consequences
resulting from such use. 

Note: All other non-example software, including binary software objects
(libraries, programs), are prohibited from distribution under terms described
in LICENSE.txt (refer to LICENSE.txt for details).
*/
/** @example mogsSimpleExample.cpp minimal example of basic MOGS use */




/**
  This is a simple example showing basic use of ARNL for path planning
  and localization.

  You can make a copy of this program's source file in the 'examples' directory
  and use it as the basis for your own program.

  For a more complete example that includes more features, including access
  from a remote client such as MobileEyes, see the Server examples.
*/

#include "Aria.h"
#include "Arnl.h"
#include "ArGPSLocalizationTask.h"


/* This class contains callback methods. ArPathPlanningTask calls these on
 * different events: when a goal is reached, when a goal fails, etc.  When these
 * events happen, these callbacks will choose a new goal from the map and send 
 * the robot there.
 */
class SimpleExample
{
public:
    SimpleExample(ArPathPlanningTask* planner, ArMap* map) :
        myPlanner(planner),
        myMap(map),
        myGoalFailedCB(this, &SimpleExample::goalFailed),
        myGoalReachedCB(this, &SimpleExample::goalReached)
    {
        planner->addGoalDoneCB(&myGoalReachedCB);
        planner->addGoalFailedCB(&myGoalFailedCB);
    }
    ~SimpleExample() 
    {
        myPlanner->remGoalDoneCB(&myGoalReachedCB);
        myPlanner->remGoalFailedCB(&myGoalFailedCB);
    }
    void goToRandomGoal() 
    {
        myMap->lock();
        std::list<ArMapObject*> goals = myMap->findMapObjectsOfType("Goal", true); /* true means also include "GoalWithHeading"*/
        long r = ArMath::randomInRange(0, goals.size()-1);
        ArLog::log(ArLog::Normal, "...randomly chose the %d'th goal (out of %d)...", r+1, goals.size());
        ArMapObject *obj = NULL;
        long n = 0;
        for(std::list<ArMapObject*>::const_iterator i = goals.begin(); i != goals.end(); ++i)
        {
            if(n++ == r)
            {
                obj = *i;
                break;
            }
        }
        ArLog::log(ArLog::Normal, "...%s", obj->getName());
        myGoalName = obj->getName();
        myPlanner->pathPlanToGoal(obj->getName());
        myMap->unlock();
    }
protected:
    ArPathPlanningTask *myPlanner;
    ArMap *myMap;
    std::string myGoalName;
    ArFunctor1C<SimpleExample, ArPose> myGoalFailedCB;
    ArFunctor1C<SimpleExample, ArPose> myGoalReachedCB;
    void goalReached(ArPose position)
    {
        ArLog::log(ArLog::Normal, "Reached goal %s! Choosing another...", myGoalName.c_str());
        goToRandomGoal();
    }
    void goalFailed(ArPose position)
    {
        ArLog::log(ArLog::Normal, "Failed to reach goal %s! Choosing another...", myGoalName.c_str());
        goToRandomGoal();
    }
};

int main(int argc, char **argv)
{
  // Initialize Aria and Arnl global information
  Aria::init();
  Arnl::init();


  // The robot object
  ArRobot robot;

  // Object used to parse the command line arguments and /etc/Aria.args
  ArArgumentParser parser(&argc, argv);

  // Object used to connect to the robot, based on command line options.
  ArRobotConnector robotConnector(&parser, &robot);

  // Connect to the robot
  if (!robotConnector.connectRobot())
  {
    ArLog::log(ArLog::Normal, "Error: Could not connect to robot... exiting");
    Aria::exit(3);
  }



  // Set up where we'll look for files (such as the map). Arnl::init() set Aria's default
  // directory to Arnl's default directory; addDirectories() appends this
  // "examples" directory.
  char fileDir[1024];
  ArUtil::addDirectories(fileDir, sizeof(fileDir), Aria::getDirectory(), 
			 "examples");
  
  
  // To direct log messages to a file, or to change the log level, use these  calls:
  //ArLog::init(ArLog::File, ArLog::Normal, "log.txt", true, true);
  //ArLog::init(ArLog::File, ArLog::Verbose);
 
  // Add a section to the configuration to change ArLog parameters
  ArLog::addToConfig(Aria::getConfig());

  // set up a gyro (if the robot is older and its firmware does not
  // automatically incorporate gyro corrections, then this object will do it)
  ArAnalogGyro gyro(&robot);


  // GPS connector.
  ArGPSConnector gpsConnector(&parser);


  // the laser connector
  ArLaserConnector laserConnector(&parser, &robot, &robotConnector);

  // Always automatically attempt to connect to the primary laser.
  // (otherwise you would have to give the -connectLaser command line option
  // each time)
  parser.addDefaultArgument("-connectLaser");
  
  // Load default arguments for this computer (from /etc/Aria.args, environment
  // variables, and other places)
  parser.loadDefaultArguments();

  // Parse arguments 
  if (!Aria::parseArgs() || !parser.checkHelpAndWarnUnparsed())
  {
    Aria::logOptions();
    Aria::exit(1);
  }
  

  // This causes Aria::exit(9) to be called if the robot unexpectedly
  // disconnects
  ArGlobalFunctor1<int> shutdownFunctor(&Aria::exit, 9);
  robot.addDisconnectOnErrorCB(&shutdownFunctor);


  // Sonar, must be added to the robot, used by teleoperation and
  // wander to detect obstacles, and by SONARNL to localize... also
  // can be used for obstacle avoidance during path planning (though that isn't generally
  // recommended and is controlled by the 'Path Planning Settings'
  // 'UseSonar' parameter)
  ArSonarDevice sonarDev;
  robot.addRangeDevice(&sonarDev);


  // This object will allow robot's movement parameters to be changed through
  // the ArConfig configuration.
  ArRobotConfig robotConfig(&robot);

  // Include gyro configuration options
  robotConfig.addAnalogGyro(&gyro);


  // Start the robot thread.
  robot.runAsync(true);
  

  // connect the laser(s) if it was requested, this adds them to the
  // ArRobot object too, and starts them running in their own threads
  if (!laserConnector.connectLasers())
  {
    ArLog::log(ArLog::Normal, "Could not connect to all lasers... exiting\n");
    Aria::exit(2);
  }



    /* Create and set up map object */
  
  // Set up the map object, this will look for files in the examples
  // directory (unless the file name starts with a /, \, or .
  // You can take out the 'fileDir' argument to look in the program's current directory
  // instead.
  // When a configuration file is loaded into ArConfig later, if it specifies a
  // map file, then that file will be loaded as the map.
  ArMap map(fileDir);
  // set it up to ignore empty file names (otherwise if a configuration omits
  // the map file, the whole configuration change will fail)
  map.setIgnoreEmptyFileName(true);
  // ignore the case, so that if someone is using MobileEyes or
  // MobilePlanner from Windows and changes the case on a map name,
  // it will still work.
  map.setIgnoreCase(true);

    
    /* Create localization and path planning threads */


  ArPathPlanningTask pathTask(&robot, &sonarDev, &map);



  // GPS initialization and GPS localization task setup.
  ArLog::log(ArLog::Normal, "Connecting to GPS...");
  ArGPS *gps = gpsConnector.createGPS(&robot);
  if(!gps || !gps->connect())
  {
    ArLog::log(ArLog::Terse, "Error connecting to GPS device."
      "Try -gpsType, -gpsPort, and/or -gpsBaud command-line arguments."
      "Use -help for help. Exiting.");
    Aria::exit(5);
  }
  ArLog::log(ArLog::Normal, "Creating GPS localization task");
  ArGPSLocalizationTask gpsLocTask(&robot, gps, &map);

  // Set some additional options on each laser that ArLaserConnector connected
  // to, and also provide them to ArPathPlanningTask to use for planning around
  // sensed obstacles.
  std::map<int, ArLaser *>::iterator laserIt;
  for (laserIt = robot.getLaserMap()->begin();
       laserIt != robot.getLaserMap()->end();
       laserIt++)
  {
    int laserNum = (*laserIt).first;
    ArLaser *laser = (*laserIt).second;

    // Skip lasers that aren't connected
    if(!laser->isConnected())
      continue;

    // add the disconnectOnError CB to shut things down if the laser
    // connection is lost
    laser->addDisconnectOnErrorCB(&shutdownFunctor);
    // set the number of cumulative readings the laser will take
    laser->setCumulativeBufferSize(200);
    // add the lasers to the path planning task
    pathTask.addRangeDevice(laser, ArPathPlanningTask::BOTH);
    // set the cumulative clean offset (so that they don't all fire at once)
    laser->setCumulativeCleanOffset(laserNum * 100);
    // reset the cumulative clean time (to make the new offset take effect)
    laser->resetLastCumulativeCleanTime();
  }

  /* Add additional range devices to the robot and path planning task (so it
     avoids obstacles detected by these devices) */

  robot.lock();
  
  // Add IR range device to robot and path planning task (so it avoids obstacles
  // detected by this device)
  ArIRs irs;
  robot.addRangeDevice(&irs);
  pathTask.addRangeDevice(&irs, ArPathPlanningTask::CURRENT);

  // Add bumpers range device to robot and path planning task (so it avoids obstacles
  // detected by this device)
  ArBumpers bumpers;
  robot.addRangeDevice(&bumpers);
  pathTask.addRangeDevice(&bumpers, ArPathPlanningTask::CURRENT);

  // Add range device which uses forbidden regions given in the map to give virtual
  // range device readings to ARNL.  (so it avoids obstacles
  // detected by this device)
  ArForbiddenRangeDevice forbidden(&map);
  robot.addRangeDevice(&forbidden);
  pathTask.addRangeDevice(&forbidden, ArPathPlanningTask::CURRENT);

  robot.unlock();


  // Action to slow down robot when localization score drops but not lost.
  ArActionSlowDownWhenNotCertain actionSlowDown(&gpsLocTask);
  pathTask.getPathPlanActionGroup()->addAction(&actionSlowDown, 140);

  // Action to stop the robot when localization is "lost" (score too low)
  ArActionLost actionLostPath(&gpsLocTask, &pathTask);
  pathTask.getPathPlanActionGroup()->addAction(&actionLostPath, 150);

  // Arnl uses this object when it must replan its path because its
  // path is completely blocked.  It will use an older history of sensor
  // readings to replan this new path.  This should not be used with SONARNL
  // since sonar readings are not accurate enough and may prevent the robot
  // from planning through space that is actually clear.
  ArGlobalReplanningRangeDevice replanDev(&pathTask);
  
  // Cause the sonar to turn off automatically
  // when the robot is stopped, and turn it back on when commands to move
  // are sent. (Note, if using SONARNL to localize, then don't do this
  // since localization may get lost)
  ArSonarAutoDisabler sonarAutoDisabler(&robot);


  /*
  // If we are on a simulator, move the robot back to its starting position,
  // and reset its odometry.
  // This will allow localizeRobotAtHomeBlocking() below will (probably) work (it
  // tries current odometry (which will be 0,0,0) and all the map
  // home points.
  // (Ignored by a real robot)
  //robot.com(ArCommands::SIM_RESET);
  */



    /* Load config, map, and begin! */

  
  // Read in parameter files.
  Aria::getConfig()->useArgumentParser(&parser);
  ArLog::log(ArLog::Normal, "Loading config file %s into ArConfig...", Arnl::getTypicalParamFileName());
  if (!Aria::getConfig()->parseFile(Arnl::getTypicalParamFileName()))
  {
    ArLog::log(ArLog::Normal, "Trouble loading configuration file, exiting");
    Aria::exit(5);
  }

  // Warn about unknown params.
  if (!parser.checkHelpAndWarnUnparsed())
  {
    ArLog::log(ArLog::Normal, "\nUsage: %s -map mapfilename\n", argv[0]);
    Aria::logOptions();
    Aria::exit(6);
  }

  // Warn if there is no map
  if (map.getFileName() == NULL || strlen(map.getFileName()) <= 0)
  {
    ArLog::log(ArLog::Terse, "\\nError: Have no map. Use the -map command line argument, or set it in the arnl.p parameter file.");
    ArLog::log(ArLog::Terse, "See docs/GPSMapping.txt.");
    ArLog::log(ArLog::Terse, "");
    Aria::exit(7);
  }


  // Print a log message notifying user of the directory for map files
  ArLog::log(ArLog::Normal, "");
  ArLog::log(ArLog::Normal, 
	     "Directory for maps and file serving: %s", fileDir);
  
  ArLog::log(ArLog::Normal, "See the ARNL README.txt for more information");
  ArLog::log(ArLog::Normal, "");

  // Do an initial localization of the robot. It tries all the home points
  // in the map, as well as the robot's current odometric position, as possible
  // places the robot is likely to be at startup.   If successful, it will
  // also save the position it found to be the best localized position as the
  // "Home" position, which can be obtained from the localization task (and is
  // used by the "Go to home" network request).
 //gpsLocTask.localizeRobotAtHomeBlocking();   // not implemented yet in ArGPSLocalizationTask, but this does the same thing:
 gpsLocTask.setIdleFlag(false);
  
  // Add a key handler so that you can exit by pressing
  // escape. Note that this key handler, however, prevents this program from
  // running in the background (e.g. as a system daemon or run from 
  // the shell with "&") -- it will lock up trying to read the keys; 
  // remove this if you wish to be able to run this program in the background.
  ArKeyHandler *keyHandler;
  if ((keyHandler = Aria::getKeyHandler()) == NULL)
  {
    keyHandler = new ArKeyHandler;
    Aria::setKeyHandler(keyHandler);
    robot.lock();
    robot.attachKeyHandler(keyHandler);
    robot.unlock();
    puts("To exit, press escape.");
  }

  // Create SimpleExample class instance (with our callbacks)
  SimpleExample example(&pathTask, &map);

  // Enable the motors 
  robot.enableMotors();

  // Choose a goal
  example.goToRandomGoal();

  //wait until the robot exits (disconnection, etc.) or this program is
  // canceled.
  robot.waitForRunExit();
  Aria::exit(0);
}

