/*

Copyright (c) 2014 Adept Technology Inc.
All rights reserved.� 

Redistribution of this example source code, with or without modification, is 
permitted provided that the following conditions are met:�� 
-��� Redistributions must retain the above copyright notice, 
     this list of conditions and the following disclaimer.� 
-� � Redistributions must be in source code form only

The information in this document is subject to change without notice and should
not be construed as a commitment by Adept Technology, Inc.

Adept Technology, Inc. makes no warranty as to the suitability of this material
for use by the recipient, and assumes no responsibility for any consequences
resulting from such use. 

Note: All other non-example software, including binary software objects
(libraries, programs), are prohibited from distribution under terms described
in LICENSE.txt (refer to LICENSE.txt for details).
*/

/* This program converts a file containing latitude and longitude coordinates to
 * a MobileRobots ArMap map file, turning coordinates into line endpoints, forbidden
 * line endpoints, or goals; the input file serves as a temporary interchange
 * point between data generated using a handheld GPS, a database, an
 * interactive GIS tool, converted from some other data file, etc. and a MobileRobots
 * map file that can be used with MOGS.
 *
 * The syntax of the input file is as follows:
 *
 * Each line of the input specifies an object to put in the ArMap. Tokens on the
 * line are separated by any number of whitespace (space or tabs) or comma or
 * semicolon characters.  The first token on each
 * line specifies the ArMap object type: Line for an obstacle line,
 * ForbiddenLine for a forbidden line, Goal for a goal.
 * The object type is then followed by latitude, longitude, altitude coordinates in the
 * WGS84 datum. If the type is a Line or ForbiddenLine, then it must have two
 * sets of latitude, longitude, altitude coordinates specifying the end points
 * of the line.  If the type is Goal, a name for the goal ends the line.
 * Any line that begins with # is ignored.
 * 
 * In addition to objects defined in the input, this program adds a Line around
 * the outside bounds of the map unless -noBoundsLine is given. This helps improve performance of path
 * planning, and also works around a bug in a previous version of MOGS.
 *
 * Example:
 * 
 * # Example input GPS coords.
 * Line 42.807471 -71.578535 60 42.807543 -71.577974 61.5
 * Line 42.807543 -71.577974 61.5 42.807079 -71.578157 61.89
 * Line 42.807079 -71.578157 61.89 42.807327 -71.579307 61
 * Line 42.807327 -71.579307 61 42.807471 -71.578535 60
 * Goal 42.807096,-71.579066 60 Start
 * Goal 42.807157,-71.579579 60 Gate2
 * Goal 42.807838,-71.578881 62 Hilltop
 * ForbiddenLine 42.808066,-71.579162,60 42.807777,-71.57773,60
 * ForbiddenLine 42.807777,-71.57773,60 42.806311,-71.578301,60
 * ForbiddenLine 42.806311,-71.578301,60 42.807002,-71.579594,60
 * ForbiddenLine 42.807002,-71.579594,60 42.808066,-71.579162,60
 * 
 * Run this program on the command line like this:
 *
 * convertCoordsToArMap [-input <inputfile>] [-output <outputfile>] [-latOffset <latOffset>] [-lonOffset <lonOffset>]
 *
 * The -latOffset and -lonOffset parameters are optional and default to 0.
 * If -input is not given, input is read from standard input. If -output is not
 * given, then <inputfile>.map is used, or convertedCoords.map if -input was
 * not given. 
 * 
 * Wishlist:
 * Useful additions to this program would include allowing a series of points,
 * each pair of which results in a Line or ForbiddenLine segment, and
 * supporting ForbiddenArea objects and other sector types.
 */


#include "Aria.h"

struct Line
{ 
  ArLLACoords start;
  ArLLACoords end;
};

void updateBounds(const Line& l, double& latMin, double& latMax, double& lonMin, double& lonMax, double& altMin, double& altMax)
{
    latMin = ArUtil::findMin(latMin, ArUtil::findMin(l.start.getLatitude(), l.end.getLatitude()));
    latMax = ArUtil::findMax(latMax, ArUtil::findMax(l.start.getLatitude(), l.end.getLatitude()));
    lonMin = ArUtil::findMin(lonMin, ArUtil::findMin(l.start.getLongitude(), l.end.getLongitude()));
    lonMax = ArUtil::findMax(lonMax, ArUtil::findMax(l.start.getLongitude(), l.end.getLongitude()));
    altMin = ArUtil::findMin(altMin, ArUtil::findMin(l.start.getAltitude(), l.end.getAltitude()));
    altMax = ArUtil::findMax(altMax, ArUtil::findMax(l.start.getAltitude(), l.end.getAltitude()));
}

void updateBounds(const ArLLACoords& c, double& latMin, double& latMax, double& lonMin, double& lonMax, double& altMin, double& altMax)
{
    latMin = ArUtil::findMin(latMin, c.getLatitude());
    latMax = ArUtil::findMax(latMax, c.getLatitude());
    lonMin = ArUtil::findMin(lonMin, c.getLongitude());
    lonMax = ArUtil::findMax(lonMax, c.getLongitude());
    altMin = ArUtil::findMin(altMin, c.getAltitude());
    altMax = ArUtil::findMax(altMax, c.getAltitude());
}

void updateBounds(const double& x, const double& y, double& xmin, double& xmax, double& ymin, double &ymax)
{
  xmin = ArUtil::findMin(xmin, x);
  xmax = ArUtil::findMax(xmax, x);
  ymin = ArUtil::findMin(ymin, y);
  ymax = ArUtil::findMax(ymax, y);
}

int main(int argc, char **argv)
{
  Aria::init();
  std::string inputFileName;
  std::string outputFileName;
  bool haveInputFileName = false;
  bool haveOutputFileName = false;
  ArArgumentParser parser(&argc, argv);

  const char *s;
  if(!parser.checkParameterArgumentString("-input", &s, &haveInputFileName))
  {
    ArLog::log(ArLog::Terse, "error parsing command line.");
    Aria::exit(1);
  }
  if(haveInputFileName) inputFileName = s;

  s = NULL;
  if (!parser.checkParameterArgumentString("-output", &s, &haveOutputFileName))
  {
    ArLog::log(ArLog::Normal, "error parsing command line");
    Aria::exit(1);
  }
  if(haveOutputFileName) outputFileName = s;

  double longitudeOffset = 0.0;
  if (!parser.checkParameterArgumentDouble("-lonOffset", &longitudeOffset))
  {
    ArLog::log(ArLog::Normal, "Bad longitude offset");
    Aria::exit(1);
  }
  double latitudeOffset = 0.0;
  if (!parser.checkParameterArgumentDouble("-latOffset", &latitudeOffset))
  {
    ArLog::log(ArLog::Normal, "Bad latitude offset");
    Aria::exit(1);
  }

  bool addBoundingLine = true;
  if(parser.checkArgument("-noBoundsLine"))
    addBoundingLine = false;

  if(!parser.checkHelpAndWarnUnparsed())
  {
    ArLog::log(ArLog::Normal, "usage: convertCoordsToArMap [-input <inputfile>] [-output <outputfile>] [-latOffset <latOffset>] [-lonOffset <lonOffset>]\n\n"\
"The -latOffset and -lonOffset parameters are optional and default to 0."\
"If -input is not given, input is read from standard input. If -output is not"\
"given, then <inputfile>.map is used, or convertedCoords.map if -input was"\
"not given.");
    Aria::exit(0);
  }


  FILE *inputFile = NULL;
  if(haveInputFileName)
  {
    ArLog::log(ArLog::Normal, "Reading input file %s...", inputFileName.c_str());
    inputFile = ArUtil::fopen(inputFileName.c_str(), "r", false);
    if(inputFile == NULL)
    {
      ArLog::log(ArLog::Normal, "Cannot open input file %s", inputFileName.c_str());
      exit(1);
    }
    if(!haveOutputFileName)
    {
      outputFileName = inputFileName + ".map";
      haveOutputFileName = true;
    }
  }
  else
  {
    ArLog::log(ArLog::Normal, "Reading input from standard input...");
    inputFileName = "<stdin>";
    inputFile = stdin;
    if(!haveOutputFileName)
    {
      outputFileName = "convertedCoords.map";
      haveOutputFileName = true;
    } 
  }

  std::list<Line> lines;
  std::list<Line> forbiddenLines;
  std::map<std::string, ArLLACoords> goals;
  double latMax = -180.0, lonMax = -180.0, altMax = 0;
  double latMin = 180.0, lonMin = 180.0, altMin = 0;
  char buf[100000];
  unsigned long lineno = 0;
  while(fgets(buf, sizeof(buf), inputFile) != NULL)
  {
    ++lineno;
    char *tok = strtok(buf, " \t,;");
    if(tok == NULL || tok[0] == '#') 
      continue;
    std::string type = tok;
    std::vector<std::string> tokens;
    while((tok = strtok(NULL, " \t,;")) != NULL)
    {
      if(tok[strlen(tok)-1] == '\n')
        tok[strlen(tok)-1] = '\0';
      tokens.push_back(std::string(tok));
    }
    if(type == "Line" || type == "ForbiddenLine")
    {
      if(tokens.size() < 6)
      {
        ArLog::log(ArLog::Terse, "Error on line %lu of %s: not enough coordinates given for a %s. Must give: startLat, startLon, startAt, endLat, endLon, endAlt", lineno, inputFileName.c_str(), type.c_str());
        Aria::exit(2);
      }
      Line l;
      l.start = ArLLACoords(atof(tokens[0].c_str())+latitudeOffset, atof(tokens[1].c_str())+longitudeOffset, atof(tokens[2].c_str()));
      l.end = ArLLACoords(atof(tokens[3].c_str())+latitudeOffset, atof(tokens[4].c_str())+longitudeOffset, atof(tokens[5].c_str()));
      updateBounds(l, latMin, latMax, lonMin, lonMax, altMin, altMax);
      if(type == "Line")
        lines.push_back(l);
      else
        forbiddenLines.push_back(l);
    }
    else if(type == "Goal")
    {
      if(tokens.size() < 4)
      {
        ArLog::log(ArLog::Terse, "Error on line %lu of %s: not enough values given for Goal. Must give: latitude, longitude, altitude, name.", lineno, inputFileName.c_str());
        Aria::exit(2);
      }
      ArLLACoords coords(atof(tokens[0].c_str()), atof(tokens[1].c_str()), atof(tokens[2].c_str()));
      updateBounds(coords, latMin, latMax, lonMin, lonMax, altMin, altMax);
      goals[tokens[3]] = coords;
    }
    else
    {
      ArLog::log(ArLog::Terse, "Error on line %lu of %s: unrecognized object type %s", lineno, inputFileName.c_str(), type.c_str());
    }
  }
  fclose(inputFile);

  // Set origin as center of bounding box.
  double latCen = (latMax + latMin) / 2.0;
  double lonCen = (lonMax + lonMin) / 2.0;
  double altCen = (altMax + altMin) / 2.0;
  ArLLACoords origin(latCen, lonCen, altCen);
  ArLog::log(ArLog::Normal, "Origin is %.9f %.9f %.9f", latCen, lonCen, altCen);

  // Set up map. Add some sector type definitions.
  ArMap ariaMap;
  ArArgumentBuilder *builder1 = new ArArgumentBuilder;
  builder1->add("SectorType Name=BadGPSSector \"Label=BadGPS\" \"Desc=Area \
where GPS is known to be unreliable\" Shape=Plain Color0=0x888888");
  ariaMap.getMapInfo()->push_back(builder1);
  ArArgumentBuilder *builder2 = new ArArgumentBuilder;
  builder2->add("SectorType Name=SlowSector \"Label=Slow\" \"Desc=Area \
to drive slow in\" Shape=Plain Color0=0xcac68e");
  ariaMap.getMapInfo()->push_back(builder2);
  ArArgumentBuilder *builder3 = new ArArgumentBuilder;
  builder3->add("SectorType Name=OneWaySector \"Label=One-Way\" \"Desc=One-\
Way Area\" Shape=Plain Color0=0xAE95BD");
  ariaMap.getMapInfo()->push_back(builder3);
  ArArgumentBuilder *builder4 = new ArArgumentBuilder;
  builder4->add("SectorType Name=RestrictiveSector \"Label=Restrictive-\
Sector\" \"Desc=Restrictive Sector the robot will try to avoid (it will \
drive over if necessary)\" Shape=Plain Color0=0xd4d400");
  ariaMap.getMapInfo()->push_back(builder4);

  std::vector<ArPose>* ptsList = ariaMap.getPoints();

  // Convert LLA to map coords and add map objects to ariaMap.
  ArMapGPSCoords mapCoords(origin);
  std::vector<ArLineSegment> mapLines;
  double xmax, ymax, xmin, ymin;
  xmax = xmin = ymax = ymin = 0;
  for(std::list<Line>::const_iterator i = lines.begin(); i != lines.end(); ++i)
  {
      double x1, x2, y1, y2, z;
      mapCoords.convertLLA2MapCoords((*i).start, x1, y1, z);
      mapCoords.convertLLA2MapCoords((*i).end, x2, y2, z);
      mapLines.push_back(ArLineSegment(x1, y1, x2, y2));
      updateBounds(x1, y1, xmin, xmax, ymin, ymax);
      updateBounds(x2, y2, xmin, xmax, ymin, ymax);
  }
  std::list<ArMapObject*> mapObjects;
  for(std::list<Line>::const_iterator i = forbiddenLines.begin(); i != forbiddenLines.end(); ++i)
  {
      double x1, x2, y1, y2, z;
      mapCoords.convertLLA2MapCoords((*i).start, x1, y1, z);
      mapCoords.convertLLA2MapCoords((*i).end, x2, y2, z);
      mapObjects.push_back(new ArMapObject("ForbiddenLine", 
				    ArPose((x1+x2)/2.0, (y1+y2)/2.0, 0.0),
					    "", "ICON", "", true, 
					    ArPose(x1, y1),
					    ArPose(x2, y2))
      );
      updateBounds(x1, y1, xmin, xmax, ymin, ymax);
      updateBounds(x2, y2, xmin, xmax, ymin, ymax);
  }
  for(std::map<std::string, ArLLACoords>::const_iterator i = goals.begin(); i != goals.end(); ++i)
  {
    double x, y, z;
    mapCoords.convertLLA2MapCoords((*i).second, x, y, z);
    mapObjects.push_back(new ArMapObject("Goal", ArPose(x, y), "", "ICON", (*i).first.c_str(), false, ArPose(x, y), ArPose(x, y)));
    updateBounds(x, y, xmin, xmax, ymin, ymax);
  }

  if(addBoundingLine)
  {
    xmin -= 50000;   // 50 meter padding from nearest thing
    xmax += 50000;
    ymin -= 50000;
    ymax += 50000;
    mapLines.push_back(ArLineSegment(xmin, ymax, xmax, ymax));
    mapLines.push_back(ArLineSegment(xmax, ymax, xmax, ymin));
    mapLines.push_back(ArLineSegment(xmax, ymin, xmin, ymin));
    mapLines.push_back(ArLineSegment(xmin, ymin, xmin, ymax));
  }

  ariaMap.setPoints(ptsList);
  ariaMap.setLines(&mapLines);
  ariaMap.setMapObjects(&mapObjects);
  ariaMap.setOriginLatLongAlt(true, ArPose(origin.getLatitude(), origin.getLongitude()), origin.getAltitude());

  // Write output
  ArLog::log(ArLog::Normal, "Writing %s...", outputFileName.c_str());
  ariaMap.writeFile(outputFileName.c_str());
    
  return 0;
}


