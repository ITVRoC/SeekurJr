/*
Adept MobileRobots Advanced Robotics Navigation and Localization (ARNL)
Version 1.9.0

Copyright (C) 2004, 2005 ActivMedia Robotics LLC
Copyright (C) 2006-2009 MobileRobots Inc.
Copyright (C) 2010-2014 Adept Technology, Inc.

All Rights Reserved.

Adept MobileRobots does not make any representations about the
suitability of this software for any purpose.  It is provided "as is"
without express or implied warranty.

The license for this software is distributed as LICENSE.txt in the top
level directory.

robots@mobilerobots.com
Adept MobileRobots
10 Columbia Drive
Amherst, NH 03031
+1-603-881-7960

*/
/* ****************************************************************************
 * 
 * File: ArGPSLocalizationTask.h
 * 
 * Function: Header file for the GPSLocalizationTask.cpp file.
 *
 * Created:  George V. Paul. gvp@activmedia.com. Aug 1 2007.
 *
 *****************************************************************************/
#ifndef ARGPSLOCALIZATIONTASK_H
#define ARGPSLOCALIZATIONTASK_H
#include "Aria.h"
#include "ArRobotPoseProb.h"
#include "ArMatrix.h"
#include "arnlInternal.h"
#include "ArBaseLocalizationTask.h"
#include "ArGPS.h"
#include "ArGPSCoords.h"
#include "ArGPSConnector.h"
#include "ArNetworking.h"

#include <set>
#include <vector>
#include <algorithm>

#define RADS2DEGS  57.29577951
#define DEGS2RADS  0.017453293
#define SQRT_OF_2 1.41421356237309504880

typedef double ArnlFloat;

class ArGPSLocalizationTask;
class ArLLACoords;
class ArECEFCoords;
class ArENUCoords;
class ArWGS84;

#ifndef SWIG
/*
 * The kalman filter class which takes odometry and gps data to compute
 * the robot state.
 *
 * @internal
 *
 */
class ArKalmanFilterGPS
{
  public:
  /// Constructor.
  ArKalmanFilterGPS(int stateSize, ArMatrix x0, ArMatrix p0, 
		    ArGPSLocalizationTask* gpsPtr) :
  myXSize(stateSize),
  myX(x0),
  myP(p0),
  myGPSPtr(gpsPtr)
  {}
  /// Actual function that does the filter step.
  bool runFilterStep(ArPose deltaPose,
		     ArPose GPSPose,
		     ArPose& encoderPose,
		     double compassAngle,
		     ArPose vel,
		     bool GPS,
		     bool compass,
		     ArPose DOP,
		     ArPose GPSError,
		     double compErr,
		     double deltaT,
		     ArPose& kalPose,
		     ArPose& kalVel,
		     bool useAllH=false);
  /// Get size of state vector.
  /// Get size of state vector.
  int  getStateSize(void) 
  {
    myMutex.lock();
    int s = myXSize;
    myMutex.unlock();
    return s; 
  }
  /// Get P
  ArMatrix getP(void) 
  {
    myMutex.lock();
    ArMatrix P = myP; 
    myMutex.unlock();
    return P; 
  }
  /// Get P
  ArMatrix getR(void) 
  {
    myMutex.lock();
    ArMatrix R = myR; 
    myMutex.unlock();
    return R; 
  }
  /// Get X
  ArMatrix getX(void) 
  {
    myMutex.lock();
    ArMatrix X = myX; 
    myMutex.unlock();
    return X; 
  }
  /// Get X
  ArPose getCurrentPose(void) 
  {
    myMutex.lock();
    ArMatrix X = myX; 
    myMutex.unlock();
    return ArPose(X(0), X(1), X(2)); 
  }
  /// Get encoder pose at last compute.
  ArPose getLastLocaEncoderPose(void) 
  {
    myMutex.lock();
    ArPose p = myLastLocaEncoderPose;
    myMutex.unlock();
    return p; 
  }
  /// Set encoder pose at last compute.
  void setLastLocaEncoderPose(ArPose p) 
  {
    myMutex.lock();
    myLastLocaEncoderPose = p;
    myMutex.unlock();
  }
  /// Set size of state vector.
  void  setStateSize(int s)
  {
    myMutex.lock();
    myXSize = s;
    myMutex.unlock();
  }
  /// Set P
  void setP(ArMatrix P)
  {
    myMutex.lock();
    myP = P;
    myMutex.unlock();
  }
  /// Set R
  void setR(ArMatrix R)
  {
    myMutex.lock();
    myR = R; 
    myMutex.unlock();
  }
  /// Set X
  void setX(ArMatrix x)
  {
    myMutex.lock();
    myX = x; 
    myMutex.unlock();
  }
  /// Set X
  void setCurrentPose(ArPose p)
  {
    ArMatrix X(3, 1);
    X(0) = p.getX(); X(1) = p.getY(); X(2) = p.getTh();
    setX(X);
  }

  protected:
  int myXSize; // Kalman base state size.
  ArMatrix myX; // Kalman state.
  ArMatrix myP; // Kalman plant covariance.
  ArMatrix myR; // Kalman sensor covariance.
  ArMutex myMutex;
  ArGPSLocalizationTask* myGPSPtr;
  ArPose myLastLocaEncoderPose;
};
#endif

/*!  
 *  This class encapsulates an ArRobot sensor interpretation task that 
 *  keeps track of the pose of a robot by using GPS, IMU and odometry
 *  data.
 */
class ArGPSLocalizationTask: public ArBaseLocalizationTask
{
  friend class ArKalmanFilterGPS;

  public:

  /// Base constructor 
  AREXPORT ArGPSLocalizationTask(ArRobot* robot, ArGPS* gps, 
				 ArMapInterface* ma,
				 int stateSize=9);

  /// Base destructor.
  AREXPORT virtual ~ArGPSLocalizationTask(void);
  /// Lock for safe manipulation of variables.
  AREXPORT void lock() 
  { 
    myMutex.lock(); 
  }
  /// Unlock for safe manipulation of variables.
  AREXPORT void unlock() 
  { 
    myMutex.unlock(); 
  }
  /// Run the kalman filter for this cycle of data.
  AREXPORT bool updateKalmanState(bool goodGPS);
  /*
  /// Get the first fix and initialize the kalman filter.
  AREXPORT bool localizeRobotInMapInit(ArPose firstPose, int secsToWait=5);
 */
  /// Localization function mainly for initialization of robot 
  /// at a given pose. @sa localizeRobotAtHomeBlocking()
  AREXPORT bool localizeRobotInMapInit(ArPose given,
				       double stdX, double stdY, double stdT,
				       double thresFactor, bool warn = true,
				       bool setInitializedToFalse = true);
/*
  /// Function used to do the localization after motion (normally automatic).
  AREXPORT bool localizeRobotInMapMoved(double distFactor, 
					double angFactor,
					double thresFactor);
*/
  /// Gets the last successful MCLocalized pose.
  AREXPORT ArPose getCurrentLocaPose(void);
  /// Get the first fix done flag.
  AREXPORT bool getFirstFixDone(void) 
  {
    lock(); 
    bool f = myInitializedFlag && myGPSInitializedFlag; 
    unlock(); 
    return f;
  }
  /// Get drive robot for heading flag.
  AREXPORT bool getDriveForHeadingFlag(void)
  {
    lock(); 
    bool f = myDriveForHeadingFlag;
    unlock(); 
    return f;
  }
  /// Get drive robot for heading distance.
  AREXPORT double getDriveForHeadingDistance(void)
  {
    lock(); 
    bool f = myDriveForHeadingDistance;
    unlock(); 
    return f;
  }
  /// Gets the Pass threshold for localization success.
  AREXPORT double getPassThreshold(void) 
  {
    myMutex.lock();
    double ret = myPassThreshold;
    myMutex.unlock();
    return ret;
  }
  /// Get the localization score.
  AREXPORT double getGPSScore(void)
  {
    double p;
    myMutex.lock();
    p = myGPSScore;
    myMutex.unlock();
    return p;
  }
  /// Get drive robot for heading flag;
  AREXPORT void setDriveForHeadingFlag(bool f)
  {
    lock(); 
    myDriveForHeadingFlag = f;
    unlock(); 
  }
  // Sets the idle flag. (internal)
  AREXPORT void setIdleFlag(bool f);
  // Sets the map reloading flag. (internal)
  AREXPORT void setReloadingMapFlag(bool f);
  /// Convert compass heading wrt N to theta in ENU coords.
  AREXPORT double convertCompassToHeading(double comp, double declination)
  {
    return ArMath::fixAngle(90 - (comp + declination));
  }
  /// Gets the origin latitude and longitude for use with the map.
  AREXPORT ArPose getOriginLatLong(void)
  {
    if(myLLA0)
//      return ArPose((*myLLA0)(0), (*myLLA0)(1));
      return ArPose(myLLA0->getX(), myLLA0->getY());
    else
    {
      ArLog::log(ArLog::Normal, "No origin defined yet");
      return ArPose();
    }
  }
  /// Gets the origin latitude and longitude for use with the map.
  AREXPORT double getOriginAltitude(void)
  {
    if(myLLA0)
//      return (*myLLA0)(2);
      return myLLA0->getZ();
    else
    {
      ArLog::log(ArLog::Normal, "No origin defined yet");
      return -1e10;
    }
  }
AREXPORT bool haveOrigin();
private:
  bool resetOrigin(const ArLLACoords& lla, double px = 0.0, double py = 0.0); 
  bool setOriginHere(int secsToWait = 3);
public:
/*
  /// Compute heading from consecutive GPS points.
  AREXPORT bool driveRobotForHeadingFromGPS(ArPose firstPose,
						   double stdX, double stdY, 
						   double stdT,
						   double thresFactor,
						   bool warn, 
						   bool setInitializedToFalse);
*/
  /** Compute heading from consecutive GPS points. Normally this is done by the
  user via the DriveForHeadingBegin and DRiveForHeadingEnd commands in
  MobileEyes.
  */
  AREXPORT bool computeHeadingFromGPS(bool goodGPS,
				      ArPose& gpsPose, 
				      ArPose& odoPose, 
				      ArPose& deltaOdoPose, 
				      ArPose& odoEncoderPose,
				      double& gpsTurn, 
				      ArPose& velPose, 
				      ArPose& dop, 
				      ArENUCoords& enu,
				      double& heading);
  // Function for adding gps info to the .2d (internal)
  AREXPORT void addScanInfo(ArServerHandlerMapping* mapping);
  // The actual mean var calculator for the virtual in the base class.
  AREXPORT virtual bool findLocalizationMeanVar(ArPose& mean, ArMatrix& Var);
  // Sets the flag deciding whether to reflect localized pose onto the robot.
  AREXPORT virtual void setCorrectRobotFlag(bool f)
  {
    myMutex.lock();
    myCorrectRobotFlag = f;
    myMutex.unlock();
  }
  /// Reset localization at a new robot position.
  AREXPORT virtual void setRobotPose(ArPose pose,
				     ArPose spread = ArPose(0, 0, 0), 
				     int nSam = 0);
  /// Gets the lost flag.
  AREXPORT virtual bool getRobotIsLostFlag(void) 
  {
    return !getFirstFixDone();
  }
  /// Convert latitude and longitude to robot/map coordinates (ENU). For internal MOGS use, see ArGPSCoords for utility to do general conversions.
  AREXPORT virtual bool convertLLA2RobotCoords(double lat, double lon, 
					       double alt,
					       double& ea, double& no, 
					       double& up);
  /// Convert ENU to LLA. For internal use, see ArGPSCoords instead for a utility to do general conversions.
  AREXPORT virtual bool convertRobot2LLACoords(double ea, double no, 
					       double up,
					       double& lat, double& lon,
					       double& alt);

  /// Get the localization state.
  AREXPORT virtual LocalizationState getState(void);
  /// Gets the idle flag.
  AREXPORT virtual bool getIdleFlag(void);
  /// Gets the map reloading flag.
  AREXPORT bool getReloadingMapFlag(void);
  /// Get the localization score.
  AREXPORT virtual double getLocalizationScore(void);
  /// Gets the localization threshold.
  AREXPORT virtual double getLocalizationThreshold(void)
  {
    return getPassThreshold();
  }
  AREXPORT bool getLogFlag(void);
  
  AREXPORT virtual void setLocalizationIdle(bool f)
  {
    setIdleFlag(f);
    return;
  }
  /** Initialize localization by choosing which position has the best score:
  * assuming current robot odometric position is correct in this map, then by
  * trying any home points in the map.  If any of these corresponds to the
  * robot's current GPS localization (based on map's georeference origin point),
  * then MOGS will be successfully localized. If not, it will not start out
  * localized and the localization score will be 0.
  */
  AREXPORT virtual bool localizeRobotAtHomeBlocking() 
  {
    return localizeRobotAtHomeBlocking(0.0, 0.0, 0.1);
  }
  AREXPORT virtual bool localizeRobotAtHomeBlocking(double distSpread,
						    double angleSpread,
						    double probThreshold)
  {
    return localizeRobotAtHomeBlocking(distSpread, distSpread, 
				       angleSpread, probThreshold);
  }
  AREXPORT bool   localizeRobotAtHomeBlocking(double distSpreadX,
					      double distSpreadY,
					      double angleSpread,
					      double probThreshold);
  /// Gets the pose that robot was originally localized to
  AREXPORT virtual ArPose getRobotHome(void);
  /// Adds a callback which will be called when loca fails.
  AREXPORT void   addFailedLocalizationCB(ArFunctor1<int>* functor);
  /// Removes a callback.
  AREXPORT void   remFailedLocalizationCB(ArFunctor1<int>* functor);


  /// Helper debug drawing routines.
  AREXPORT void drawGPSPoints(ArServerClient* client, 
			      ArNetPacket* packet);
  AREXPORT void drawKalmanPoints(ArServerClient* client, 
				 ArNetPacket* packet);
  AREXPORT void drawOdoPoints(ArServerClient* client, 
			      ArNetPacket* packet);
  AREXPORT void drawKalmanRangePoints(ArServerClient* client, 
				      ArNetPacket* packet);
  AREXPORT void drawKalmanVariance(ArServerClient* client, 
				   ArNetPacket* packet);
private:
  std::vector<ArPose>  makeMeanVarPoints(ArPose& mean, ArMatrix& Var);
public:
/*
  /// Gets the position the robot was at at the given timestamp
  /// @see ArInterpolation::getPose 
  AREXPORT int getPoseInterpPosition(ArTime timeStamp, ArPose *position)
  { return myInterpolation.getPose(timeStamp, position); }
*/  
  /// Pull data off the robot instead of from the gps as was done earlier.
  double getGPSXPos() 
  { 
    return myRobot->getRobotParams()->getGPSX(); 
  }
  /// Pull data off the robot instead of from the gps as was done earlier.
  double getGPSYPos() 
  { 
    return myRobot->getRobotParams()->getGPSY(); 
  }
  /// Calling this from main will set up heading commands on dropdown menu.
  AREXPORT void addLocalizationInitCommands(
	  ArServerHandlerCommands* handlerCommands);
  // Calling this from main will set up conversion commands on dropdown menu.
  //AREXPORT void addConvertLLA2ENUCommands(
//	  ArServerHandlerCommands* handlerCommands);
  /// Set the handler config pointer.
  AREXPORT void setHandlerConfig(ArServerHandlerConfig* handlerConfig)
  {
    myMutex.lock();
    myServerHandlerConfig = handlerConfig;
    myMutex.unlock();
  }
  /// Finds the current lat lon alt from GPS if available.
  AREXPORT ArGPS::Data findCurrentLLA(int secsToWait);
  /// Finds the error increasing factor if the robot is in a bad GPS sector.
  AREXPORT double findGPSSectorFactor(ArPose pose);
  /// Finds the error of the gps data in East and North directions.
  AREXPORT ArPose findGPSError(ArPose dop, ArPose odoPose);

  protected:
  /// Function to setup the config params.
  void          setupLocalizationParams(void);
  /// Function used to run the task as a thread.
  virtual void* runThread(void* ptr);
  /// Function for the things to do if map changes.
  void          mapChanged(void);
  /// Needed if the params are changed or loaded again.
  bool          reconfigureLocalization(void);
  /// Put the Sick data into the buffer for display purposes.
  void          putRangeIntoBuffer(ArPose pose, ArPose robotPose);
  /// Check if the GPS is valid (valid fix, and have received data and DOPs)
  bool          validGPSData(void);
  /// Check if the GPS fix type is valid (not bad or none)
  bool          validGPSFixType();
  /// Fit a line to GPS points and compute the heading in ENU coords.
  double        computeHeadingFromGPSPoints(void);
  /// Start calls for drive for heading run.
  void          driveForHeadingBeginCallBack(void);
  /// During calls for drive for heading run.
  void          driveForHeadingDuringCallBack(void);
  /// End calls for drive for heading run.
  void          driveForHeadingEndCallBack(void);
  /// Apply offset to origin lat lon
  void          applyOriginOffsetCallBack(void);
  /// Finds if a point inside a polygon.
  bool          insidePolygon(std::vector<ArPose> points, ArPose p);

  private:

  ArRobot*            myRobot;
  ArGPS*              myGPS;                     // GPS
  ArMapInterface*     myMap;                     // Map data.

  bool                myLocalizingFlag;  // Localizing going on.
  bool                myInitializedFlag; // Robot pose is initialized.
  bool                myGPSInitializedFlag;// Robot pose is initialized.

  ArPose              myHomePose;        // where we started off localizing to
  bool                myHomePoseSet;     // starting point was a home point


  LocalizationState   myState;           // Current state

  ArMutex             myMutex;
  ArMutex             myDisplayMutex;

  bool                myDisplayGPSRet;
  ArMatrix            myDisplayGPSVar;
  ArPose              myDisplayGPSMean;

  ArJoyHandler*       myJoyHandler;

  int                 myStateSize;
  ArKalmanFilterGPS*  myKalman;
  ArECEFCoords*       myECEF0;
  ArLLACoords*        myLLA0;
  ArENUCoords*        myGPSHeadingENU;
  ArMapGPSCoords*     myMapGPSCoords;
  ArPose              myOdoOffset;
  ArPose              myOdoPose;
  ArPose              myOdoEncoderPose;
  ArPose              myGPSHeadingOdoEncoderPose;
  ArTransform         myEncToGlo;
  ArTransform         myEncToLocalization;
  ArTransform         myEncToLocaInit;
  ArPose              myGPSHeadingPose;
  ArPose              myDOP;
  ArTime              myClock;
  ArGPS::Data         myGPSData;
  ArGPS::Data         mySyncGPSData;

  std::list<ArGPS::Data> myGPSDataRing;     // For history.
  int                    myGPSDataRingSize;

  std::list<ArGPS::Data> myDriveForHeadingGPSData;     // For heading.
  ArPose              myDriveForHeadingBeginEncoderPose;
  ArPose              myDriveForHeadingDuringEncoderPose;
  ArPose              myDriveForHeadingEndEncoderPose;

  std::list<ArPose>   myGPSBuffer;          // For display 
  std::list<ArPose>   myKalmanBuffer;
  std::list<ArPose>   myOdoBuffer;
  std::list<ArPose>   myKalmanRangeBuffer;
  int                 myDisplaySize;

  ArConfig*           myParams;             // Default params holder.

  std::list<ArFunctor1<int>*> myFailedLocalizationCBList;

  double              myFRTKError;          // Config params.
  double              myRTKError;
  double              myDGPSError;
  double              myGPSError;
  double              myBadGPSFactor;
//  double              myDeclination;
  bool                myUseFirstAngleFixFlag;
  double              myFirstAngleFix;
  double              myInitStdX;
  double              myInitStdY;
  double              myInitStdTh;

  bool                myDriveForHeadingFlag;
  double              myDriveForHeadingDistance;
  double              myDriveForHeadingIncrement;
  int                 myDriveForHeadingMaxPoints;

//  bool                myUseCompass;
  int                 myInitFactor;

  double              myLostThreshold;
  double              myPassThreshold;   // Threshold to pass localization.
  double              myGPSScore;


  double              myKMMPerMMLin;
  double              myKMMPerMMLat;
  double              myKDegPerDeg;
  double              myKDegPerMMLin;
  double              myKDegPerMMLat;
  double              myDistanceThreshold;

  bool                myIdleFlag;
  bool                myReloadingMapFlag;

  double              myRLinVel;
  double              myRLatVel;
  double              myRRotVel;

  double              myQTra;
  double              myQRot;
  double              myQTraVel;
  double              myQRotVel;
  double              myQTraAcc;
  double              myQRotAcc;
  double              myQZeroSpeedFactor;
  double              myXYLimit;
  double              myThLimit;

  bool                myUseGPSHeading;
  double              myGPSHeadingDist;
  double              myGPSHeadingLinVel;
  double              myGPSHeadingLatVel;
  double              myGPSHeadingRotVel;
  double              myGPSHeadingDOP;
  double              myGPSHeadingTurn;
  double              myGPSHeadingError;

  std::string         myStartedMapString;

  bool                myUseAllKFlag;

  FILE*               myLogFile;
  bool                myLogFlag;
  bool                myErrorLogFlag;
  ArPose              myError;

  ArRetFunctorC<bool, ArGPSLocalizationTask>* myProcessFileCB; // Config.
  ArFunctorC<ArGPSLocalizationTask>*          myMapChangedCB;

  bool                myCorrectRobotFlag;

  /// Callbacks.
  ArFunctorC<ArGPSLocalizationTask> myDriveForHeadingBeginCB;
  ArFunctorC<ArGPSLocalizationTask> myDriveForHeadingDuringCB;
  ArFunctorC<ArGPSLocalizationTask> myDriveForHeadingEndCB;
  ArFunctorC<ArGPSLocalizationTask> myApplyOriginOffsetCB;

  double              myDriveDirection;
  
  double              myLatitudeOffset;
  double              myLongitudeOffset;
  ArPose              myXYOffset;

  std::vector<std::vector<ArPose> >  myBadGPSSectors;

  ArServerHandlerConfig*            myServerHandlerConfig;


};

#endif // ARGPSLOCALIZATIONTASK_H
